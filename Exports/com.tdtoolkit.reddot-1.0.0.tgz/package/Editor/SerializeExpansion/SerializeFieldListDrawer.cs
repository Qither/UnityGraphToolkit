#if UNITY_EDITOR
using PiRhoSoft.Utilities;
using PiRhoSoft.Utilities.Editor;
using SerializeExpansion.Runtime;
using System;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace SerializeExpansion.Editor
{
    [CustomPropertyDrawer(typeof(SerializeFieldListAttribute))]
    public class SerializeFieldListDrawer : PropertyDrawer
    {
        private const string INVALID_TYPE_WARNING = "(NPBehave) invalid type for ListAttribute on field '{0}': List can only be applied to SerializedList or SerializedArray fields";
        private const string INVALID_ADD_CALLBACK_WARNING = "(NPBehave) invalid add callback for ListAttribute on field '{0}': The method must accept an int or have no parameters";
        private const string INVALID_ADD_REFERENCE_CALLBACK_WARNING = "(NPBehave) invalid add callback for ListAttribute on field '{0}': The method must accept an int and/or an object in either order or have no parameters";
        private const string INVALID_REMOVE_CALLBACK_WARNING = "(NPBehave) invalid remove callback for ListAttribute on field '{0}': The method must accept an int or have no parameters";
        private const string INVALID_REORDER_CALLBACK_WARNING = "(NPBehave) invalid reorder callback for ListAttribute on field '{0}': The method must accept two ints or have no parameters";
        private const string INVALID_CHANGE_CALLBACK_WARNING = "(NPBehave) invalid change callback for ListAttribute on field '{0}': The method must have no parameters";

        public override VisualElement CreatePropertyGUI(SerializedProperty property)
        {
            var items = property.FindPropertyRelative(SerializedFieldList<string>.ItemsProperty);

            if (items != null && items.isArray)
            {
                Type fieldTypeBaseType = this.fieldInfo.FieldType.BaseType;
                var  isReference       = fieldTypeBaseType != null && fieldTypeBaseType.GetGenericTypeDefinition() == typeof(SerializeReferenceList<>);
                var  referenceType     = isReference ? fieldInfo.GetFieldType() : null;
                var  declaringType     = fieldInfo.DeclaringType;
                var  listAttribute     = attribute as SerializeFieldListAttribute;
                var  drawer            = this.GetNextDrawer();
                var  proxy             = new SerializeListProxy(items, drawer);

                var field = new ListField
                {
                    IsCollapsable = listAttribute.IsCollapsable,
                    bindingPath = items.propertyPath,
                    Label = property.displayName
                };
                
                if (!string.IsNullOrEmpty(listAttribute.CustomLabel))
                {
                    field.Label = listAttribute.CustomLabel;
                }

                // TODO: other stuff from ConfigureField

                if (!string.IsNullOrEmpty(listAttribute.EmptyLabel))
                    field.EmptyLabel = listAttribute.EmptyLabel;

                field.AllowAdd = listAttribute.AllowAdd != ListAttribute.Never;
                field.AllowRemove = listAttribute.AllowRemove != ListAttribute.Never;
                field.AllowReorder = listAttribute.AllowReorder;

                SetupAdd(listAttribute, proxy, field, property, declaringType, isReference);
                SetupRemove(listAttribute, proxy, field, property, declaringType);
                SetupReorder(listAttribute, field, property, declaringType);
                SetupChange(listAttribute, field, property, declaringType);

                field.SetProxy(proxy, referenceType, true);

                return field;
            }
            else
            {
                Debug.LogWarningFormat(INVALID_TYPE_WARNING, property.propertyPath);
                return new FieldContainer(property.displayName, string.Empty);
            }
        }

        private void SetupAdd(SerializeFieldListAttribute listAttribute, SerializeListProxy proxy, ListField field, SerializedProperty property, Type declaringType, bool isReference)
        {
            if (field.AllowAdd)
            {
                if (!string.IsNullOrEmpty(listAttribute.AddItem))
                {
                    proxy.OnAddItem = ReflectionHelper.CreateFunctionCallback<object>(listAttribute.AddItem, declaringType, property);
                }
                
                if (!string.IsNullOrEmpty(listAttribute.AllowAdd))
                    proxy.CanAddCallback = ReflectionHelper.CreateValueSourceFunction(listAttribute.AllowAdd, property, field, declaringType, true);

                if (!string.IsNullOrEmpty(listAttribute.AddCallback))
                {
                    if (!isReference)
                    {
                        var addCallback = ReflectionHelper.CreateActionCallback(listAttribute.AddCallback, declaringType, property);
                        if (addCallback != null)
                        {
                            field.RegisterCallback<ListField.ItemAddedEvent>(evt => addCallback.Invoke());
                        }
                        else
                        {
                            var addCallbackIndex = ReflectionHelper.CreateActionCallback<int>(listAttribute.AddCallback, declaringType, property);
                            if (addCallbackIndex != null)
                                field.RegisterCallback<ListField.ItemAddedEvent>(evt => addCallbackIndex.Invoke(evt.Index));
                            else
                                Debug.LogWarningFormat(INVALID_ADD_CALLBACK_WARNING, property.propertyPath);
                        }
                    }
                    else
                    {
                        var addCallback = ReflectionHelper.CreateActionCallback(listAttribute.AddCallback, declaringType, property);
                        if (addCallback != null)
                        {
                            field.RegisterCallback<ListField.ItemAddedEvent>(evt => addCallback.Invoke());
                        }
                        else
                        {
                            var addCallbackIndex = ReflectionHelper.CreateActionCallback<int>(listAttribute.AddCallback, declaringType, property);
                            if (addCallbackIndex != null)
                                field.RegisterCallback<ListField.ItemAddedEvent>(evt => addCallbackIndex.Invoke(evt.Index));
                            else
                                Debug.LogWarningFormat(INVALID_ADD_REFERENCE_CALLBACK_WARNING, property.propertyPath);
                        }
                    }
                }
            }
        }

        private void SetupRemove(SerializeFieldListAttribute listAttribute, SerializeListProxy proxy, ListField field, SerializedProperty property, Type declaringType)
        {
            if (field.AllowRemove)
            {
                if (!string.IsNullOrEmpty(listAttribute.AllowRemove))
                {
                    proxy.CanRemoveCallback = ReflectionHelper.CreateFunctionCallback<int, bool>(listAttribute.AllowRemove, declaringType, property);

                    if (proxy.CanRemoveCallback == null)
                    {
                        var canRemove = ReflectionHelper.CreateValueSourceFunction(listAttribute.AllowRemove, property, field, declaringType, true);
                        proxy.CanRemoveCallback = index => canRemove();
                    }
                }

                if (!string.IsNullOrEmpty(listAttribute.RemoveCallback))
                {
                    var removeCallback = ReflectionHelper.CreateActionCallback(listAttribute.RemoveCallback, declaringType, property);
                    if (removeCallback != null)
                    {
                        field.RegisterCallback<ListField.ItemRemovedEvent>(evt => removeCallback.Invoke());
                    }
                    else
                    {
                        var removeCallbackIndex = ReflectionHelper.CreateActionCallback<int>(listAttribute.RemoveCallback, declaringType, property);
                        if (removeCallbackIndex != null)
                            field.RegisterCallback<ListField.ItemRemovedEvent>(evt => removeCallbackIndex.Invoke(evt.Index));
                        else
                            Debug.LogWarningFormat(INVALID_REMOVE_CALLBACK_WARNING, property.propertyPath);
                    }
                }
            }
        }

        private void SetupReorder(SerializeFieldListAttribute listAttribute, ListField field, SerializedProperty property, Type declaringType)
        {
            if (field.AllowReorder)
            {
                if (!string.IsNullOrEmpty(listAttribute.ReorderCallback))
                {
                    var reorderCallback = ReflectionHelper.CreateActionCallback(listAttribute.ReorderCallback, declaringType, property);
                    if (reorderCallback != null)
                    {
                        field.RegisterCallback<ListField.ItemReorderedEvent>(evt => reorderCallback.Invoke());
                    }
                    else
                    {
                        var reorderCallbackFromTo = ReflectionHelper.CreateActionCallback<int, int>(listAttribute.ReorderCallback, declaringType, property);
                        if (reorderCallbackFromTo != null)
                            field.RegisterCallback<ListField.ItemReorderedEvent>(evt => reorderCallbackFromTo.Invoke(evt.FromIndex, evt.ToIndex));
                        else
                            Debug.LogWarningFormat(INVALID_REORDER_CALLBACK_WARNING, property.propertyPath);
                    }
                }
            }
        }

        private void SetupChange(SerializeFieldListAttribute listAttribute, ListField field, SerializedProperty property, Type declaringType)
        {
            if (!string.IsNullOrEmpty(listAttribute.ChangeCallback))
            {
                var changeCallback = ReflectionHelper.CreateActionCallback(listAttribute.ChangeCallback, declaringType, property);
                if (changeCallback != null)
                    field.RegisterCallback<ListField.ItemsChangedEvent>(evt => changeCallback.Invoke());
                else
                    Debug.LogWarningFormat(INVALID_CHANGE_CALLBACK_WARNING, property.propertyPath);
            }
        }
    }
}
#endif